var searchData=
[
  ['changeservo',['changeServo',['../classServotor32.html#ae622d3672fec00b4cdd51172fc01ff49',1,'Servotor32']]]
];
