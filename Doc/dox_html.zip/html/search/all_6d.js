var searchData=
[
  ['micros_5fnew',['micros_new',['../group__Time.html#ga322b63c55d10cf0d6c5dfd5a71c08ee1',1,'Servotor32']]],
  ['millis_5fnew',['millis_new',['../group__Time.html#gadf9dbf691806c2ae332af469bfe42500',1,'Servotor32']]],
  ['multiping',['multiPing',['../group__Sonar.html#gacf24352853b871c8d80ccf04b4420e7d',1,'Servotor32']]]
];
