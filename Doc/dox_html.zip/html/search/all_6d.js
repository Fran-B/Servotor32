var searchData=
[
  ['micros_5fnew',['micros_new',['../group__Time.html#gabb5286bf185ff4da49121804370ef3f8',1,'Servotor32']]],
  ['millis_5fnew',['millis_new',['../group__Time.html#ga84d9f57d52f830918ee3852ede09d205',1,'Servotor32']]],
  ['multiping',['multiPing',['../group__Sonar.html#gacf24352853b871c8d80ccf04b4420e7d',1,'Servotor32']]]
];
