var searchData=
[
  ['delay_5fms',['delay_ms',['../group__Time.html#ga6960c4a72fa927e94c8fae0ab84efd97',1,'Servotor32']]],
  ['delay_5fus',['delay_us',['../group__Time.html#gaeafccdcba0cd4d04452bafe5eaf28dbb',1,'Servotor32']]]
];
