var searchData=
[
  ['delay_5fms',['delay_ms',['../group__Time.html#ga11dd9f93666837e27020f7751c01c538',1,'Servotor32']]],
  ['delay_5fus',['delay_us',['../group__Time.html#ga918ea39f92b65dc72eed7c26e2655226',1,'Servotor32']]]
];
